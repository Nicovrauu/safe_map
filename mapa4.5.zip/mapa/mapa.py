from msilib.schema import Icon
from turtle import color
import folium

mapa = folium.Map(location = [-26.3051, -48.8461], zoom_start = 12 ) 

tooltip = "Alerta"

folium.Marker([-26.3051, -48.8461], popup="Alerta de ataques", icon=folium.Icon(color="red", icon="info-sign")).add_to(mapa)
folium.Marker([-26.286520, -48.843258], popup="Alerta de ataques", icon=folium.Icon(color="red", icon="info-sign")).add_to(mapa)
folium.Marker([-26.289028, -48.900459], popup="Alerta de ataques", icon=folium.Icon(color="red", icon="info-sign")).add_to(mapa)
folium.Marker([-26.337793, -48.838545], popup="Alerta de ataques", icon=folium.Icon(color="red", icon="info-sign")).add_to(mapa)
folium.Marker([-26.336730, -48.811231], popup="Alerta de ataques", icon=folium.Icon(color="red", icon="info-sign")).add_to(mapa)
folium.Marker([-26.269079, -48.869703], popup="Alerta de ataques", icon=folium.Icon(color="red", icon="info-sign")).add_to(mapa)
folium.Marker([-26.239347, -48.816474], popup="Alerta de ataques", icon=folium.Icon(color="red", icon="info-sign")).add_to(mapa)
folium.Marker([-26.278801, -48.802890], popup="Alerta de ataques", icon=folium.Icon(color="red", icon="info-sign")).add_to(mapa)
folium.Marker([-26.331592, -48.813102], popup="Alerta de ataques", icon=folium.Icon(color="red", icon="info-sign")).add_to(mapa)
folium.Marker([-26.289584, -48.771896], popup="Alerta de ataques", icon=folium.Icon(color="red", icon="info-sign")).add_to(mapa)
folium.Marker([-26.260891, -48.804811], popup="Alerta de ataques", icon=folium.Icon(color="red", icon="info-sign")).add_to(mapa)
folium.Marker([-26.291168146927028, -48.828173191493285], popup="Caminhada segura", icon=folium.Icon(color="blue", icon="info-sign")).add_to(mapa)
folium.Marker([-26.259980, -48.866187], popup="Caminhada segura", icon=folium.Icon(color="blue", icon="info-sign")).add_to(mapa)
folium.Marker([-26.319111, -48.842435], popup="Caminhada segura", icon=folium.Icon(color="blue", icon="info-sign")).add_to(mapa)
folium.Marker([-26.308937, -48.850754], popup="Caminhada segura", icon=folium.Icon(color="blue", icon="info-sign")).add_to(mapa)

folium.Circle(radius=1000, location=[-26.212024, -48.822281], popup="Zona de guerra", color="orange", fill=True,).add_to(mapa)
folium.Circle(radius=300, location=[-26.328466, -48.906233], popup="Zona de guerra", color="black", fill=True,).add_to(mapa)
folium.Circle(radius=400, location=[-26.256432, -48.904837], popup="Zona de guerra", color="black", fill=True,).add_to(mapa)
folium.Circle(radius=100, location=[-26.317807, -48.829983], popup="Zona de guerra", color="black", fill=True,).add_to(mapa)

mapa.save(" index.html " )