import folium
from msilib.schema import Icon
from turtle import color

mapa = folium.Map(location = [-26.3051, -48.8461], zoom_start = 12 ) 

tooltip = "Alerta"


folium.Circle(radius=1000, location=[-26.212024, -48.822281], popup="Zona de guerra", color="#780400", fill=True,).add_to(mapa)
folium.Circle(radius=300, location=[-26.328466, -48.906233], popup="Zona de guerra", color="black", fill=True,).add_to(mapa)
folium.Circle(radius=400, location=[-26.256432, -48.904837], popup="Zona de guerra", color="black", fill=True,).add_to(mapa)
folium.Circle(radius=100, location=[-26.317807, -48.829983], popup="Zona de guerra", color="black", fill=True,).add_to(mapa)
folium.Circle(radius=1300, location=[-26.302983, -48.818786], popup="Zona de guerra", color="orange", fill=True,).add_to(mapa)

folium.Circle(radius=400, location=[-26.244205, -48.810233], popup="Zona de guerra", color="#A60600", fill=True,).add_to(mapa)
folium.Circle(radius=1200, location=[-26.263659, -48.807010], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa)
folium.Circle(radius=1300, location=[-26.347808, -48.779518], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa)  #aqui
folium.Circle(radius=1200, location=[-26.283535, -48.779739], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa)
folium.Circle(radius=1200, location=[-26.279808, -48.801613], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa)
folium.Circle(radius=1200, location=[-26.275420, -48.823415], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa)
folium.Circle(radius=1200, location=[-26.261179, -48.841811], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa)
folium.Circle(radius=1200, location=[-26.263659, -48.807010], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa)
folium.Circle(radius=1200, location=[-26.263659, -48.807010], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa)

mapa.save(" index.html " )