from msilib.schema import Icon
from turtle import color
import folium

mapa = folium.Map(location = [-26.3051, -48.8461], zoom_start = 12 ) 

tooltip = "Alerta"
Alerta = "Alerta de ataques"

folium.Marker([-26.3051, -48.8461], popup="Alerta de ataques", icon=folium.Icon(color="red", icon="info-sign")).add_to(mapa)
#cria um marcador
mapa.add_child(folium.ClickForMarker(popup="Alerta de ataques"))

mapa.save(" index.html " ) 