import folium
from msilib.schema import Icon
from turtle import color

mapa = folium.Map(location = [-26.3051, -48.8461], zoom_start = 12 ) 

tooltip = "Alerta"


folium.Circle(radius=1000, location=[-26.212024, -48.822281], popup="Zona de guerra", color="#780400", fill=True,).add_to(mapa) #Jardim Paraiso
folium.Circle(radius=800, location=[-26.324341, -48.908623], popup="Zona de guerra", color="black", fill=True,).add_to(mapa) #Morro do Meio
folium.Circle(radius=1300, location=[-26.298657, -48.822451], popup="Zona de guerra", color="orange", fill=True,).add_to(mapa) #Boa Vista
folium.Circle(radius=400, location=[-26.244205, -48.810233], popup="Zona de guerra", color="#A60600", fill=True,).add_to(mapa) #Aventureiro
folium.Circle(radius=1200, location=[-26.263659, -48.807010], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa) #Jardim Iririu
folium.Circle(radius=1300, location=[-26.347808, -48.779518], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa) #Paranaguamirim
folium.Circle(radius=1200, location=[-26.283535, -48.779739], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa) #Espinheiros
folium.Circle(radius=1200, location=[-26.279808, -48.801613], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa) #Comasa
folium.Circle(radius=1200, location=[-26.275420, -48.823415], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa) #Iririu
folium.Circle(radius=1200, location=[-26.261179, -48.841811], popup="Zona de guerra", color="#CC0700", fill=True,).add_to(mapa) #Bom Retiro 
folium.Circle(radius=1200, location=[-26.290569, -48.853684], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #America
folium.Circle(radius=1200, location=[-26.340759, -48.870900], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Nova Brasília
folium.Circle(radius=800, location=[-26.334680, -48.849696], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Floresta
folium.Circle(radius=700, location=[-26.333383, -48.829817], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Itaum
folium.Circle(radius=700, location=[-26.348983, -48.830657], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Petrópoles
folium.Circle(radius=1800, location=[-26.411333, -48.795449], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Itinga
folium.Circle(radius=1200, location=[-26.382917, -48.825690], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Itinga 2
folium.Circle(radius=600, location=[-26.368960, -48.839359], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Profipo
folium.Circle(radius=600, location=[-26.365724, -48.852571], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Santa Catarina
folium.Circle(radius=500, location=[-26.363228, -48.829078], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Boehmerwald

folium.Circle(radius=900, location=[-26.347164, -48.809755], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Jarivatuba 
folium.Circle(radius=600, location=[-26.332792, -48.805232], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Ulisses Guimarães
folium.Circle(radius=500, location=[-26.326377, -48.791790], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Ademar Garcia
folium.Circle(radius=500, location=[-26.321767, -48.801658], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Fatima
folium.Circle(radius=500, location=[-26.324206, -48.815570], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Guanabara
folium.Circle(radius=500, location=[-26.322200, -48.828861], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Bucarein
folium.Circle(radius=500, location=[-26.314671, -48.838401], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Anita Garibaldi
folium.Circle(radius=500, location=[-26.318376, -48.856393], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #Atiradores
folium.Circle(radius=550, location=[-26.347164, -48.809755], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa) #João Costa
folium.Circle(radius=500, location=[-26.314671, -48.838401], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa)
folium.Circle(radius=500, location=[-26.314671, -48.838401], popup="Zona de guerra", color="#E60800", fill=True,).add_to(mapa)



mapa.save(" index.html " )